from django.db import models

# Create your models here.

class ClaseModelo(models.Model):
	estado = models.BooleanField(default=True)
	fc = models.DateTimeField(auto_now_add=True)
	
	class meta:
		abstract=True

