from django.contrib import admin

# Register your models here.

from cnv.models import *

admin.site.register(Paciente)
admin.site.register(Sintoma)
