from django.apps import AppConfig


class CnvConfig(AppConfig):
    name = 'cnv'
